-DDD
-Spring Cloud
-Docker

-Usages
mvn clean package docker:build
cd target
